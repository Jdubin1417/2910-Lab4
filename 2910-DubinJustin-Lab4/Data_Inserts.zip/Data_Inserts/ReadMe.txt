
  _____  _                       _____                _   _______ _     _     
 |  __ \| |                     |  __ \              | | |__   __| |   (_)    
 | |__) | | ___  __ _ ___  ___  | |__) |___  __ _  __| |    | |  | |__  _ ___ 
 |  ___/| |/ _ \/ _` / __|/ _ \ |  _  // _ \/ _` |/ _` |    | |  | '_ \| / __|
 | |    | |  __/ (_| \__ \  __/ | | \ \  __/ (_| | (_| |    | |  | | | | \__ \
 |_|    |_|\___|\__,_|___/\___| |_|  \_\___|\__,_|\__,_|    |_|  |_| |_|_|___/
                                                                              
                                                                              
The SQL files found in this folder are to assist you in uploading some mock data to your database. It is very important that you read this if you want to use these files.

Simply select all (ctrl+a for Windows or cmd+a for Mac) of the insert statements, and paste them into the "Execute SQL" panel in the DbBrowser software.

============================================================================================================================
FAILURE TO FOLLOW THE GUIDELINES BELOW WILL RESULT IN ERRORS WHEN RUNNING THESE INSERT STATEMENTS

1. Make sure that your table names match the ER Diagram EXACTLY (e.g., Books, Authors, Users, etc.)

2. Make sure that you name your associative tables as follows: 
	- The associative table between Books and Users should be called Books_Out_On_Loan
	- The associative table between Books and Authors should be called Book_Author
	- The associative table between Books and Categories should be called Book_Category

3. The dummy data assumes you will run these inserts in the following order. If you do not run it in this order, or happen to mess up the primary keys (Id) by running these too many times,
   simply drop the tables in reverse order from below, and run them again.

	1. Users
	2. Books
	3. Authors
	4. Categories
	5. Books_Out_On_Loan
	6. Book_Author
	7. Book_Category
